struct fb_info *registered_fb3[FB_MAX] __read_mostly X Y();
struct fb_info *registered_fb7[FB_MAX] __read_mostly X("a");
struct fb_info *registered_fb8[FB_MAX] __read_mostly X("a") C;
