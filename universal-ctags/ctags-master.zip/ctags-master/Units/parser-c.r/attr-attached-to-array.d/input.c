struct fb_info *registered_fb1[FB_MAX] __read_mostly;
struct fb_info *registered_fb2[FB_MAX] __read_mostly X;
struct fb_info *registered_fb4[FB_MAX] __read_mostly X Y(1, 2);
struct fb_info *registered_fb5[FB_MAX] __read_mostly X Y(1, 2), fb6[3] _Z_;
