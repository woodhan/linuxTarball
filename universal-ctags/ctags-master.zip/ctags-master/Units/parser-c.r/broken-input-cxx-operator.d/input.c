struct a::b{
