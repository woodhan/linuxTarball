struct {
  int x;
};

union {
  int x;
};

enum {
  X;
};
