use constant{,=>

