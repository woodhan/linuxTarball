public class C {
  private System.String m_name;
}
