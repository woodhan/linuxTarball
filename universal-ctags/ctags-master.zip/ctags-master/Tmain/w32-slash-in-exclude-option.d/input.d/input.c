int capture_me_0(void)
{
	return 0;
}
